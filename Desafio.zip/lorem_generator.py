lorem = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis nisl, convallis id libero nec, mattis molestie justo. Donec viverra elit a nibh luctus vulputate. Sed tincidunt mauris vel ex varius, a venenatis sem malesuada. Fusce in felis blandit, porta lacus eget, laoreet felis. Curabitur vitae venenatis ante. In in nisl a ex lobortis euismod. Suspendisse finibus imperdiet lacus. Integer eu ipsum tempus, malesuada diam quis, imperdiet lorem. Etiam ultrices pharetra nisi, et cursus ligula feugiat eget. Praesent eu sem lectus.\n\n'

n = int(input("Ingrese número de parrafos\n"))

print(lorem*n)