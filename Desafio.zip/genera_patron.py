n = int(input("Ingrese un número para comenzar la cuenta\n"))

output = ''
for i in range(1, n + 1):
        output += str(i)
        print(output)